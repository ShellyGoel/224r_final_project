# MIDI Data

## `rousseau`

There are 2 MIDI files in this directory containing 2 short snippets of music taken from [Rousseau](https://www.youtube.com/channel/UCPZUQqtVDmcjm4NY5FkzqLA) performances. We have gotten explicit permission from Rousseau to use these MIDI files in this benchmark.

## `pig_single_finger`

This directory will be created after the PIG dataset has been downloaded from the official website and upon running `robopianist preprocess`. These MIDI files (saved as `.proto` files) retain their original license.
